package com.example.scrdecoder

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class LockScreenActivity : AppCompatActivity() {
    private val correctPin = "1234"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lock)

        val pinInput = findViewById<EditText>(R.id.pin_input)
        val unlockButton = findViewById<Button>(R.id.unlock_button)

        unlockButton.setOnClickListener {
            if (pinInput.text.toString() == correctPin) {
                startActivity(Intent(this, MainActivity::class.java))
                finish()
            } else {
                pinInput.error = "Incorrect PIN"
            }
        }
    }
}
